# PC-PLAN-017 — Archive App Dialog

**Status:** Backlog
**Agente:** frontend-specialist
**Prioridade:** Baixa — UX, não bloqueante
**Depende de:** PC-SPEC-010 (Admin Panel)

## Critérios de aceite

- [ ] AlertDialog shadcn/ui substituindo confirm() para arquivar app
- [ ] Dialog mostra nome da aplicação
- [ ] Ação e cancelamento funcionando
- [ ] Verificar e corrigir deletar categoria se usar confirm()
- [ ] Teste B5 aprovado

## Tarefas

| # | Tarefa | Estimativa |
|---|--------|-----------|
| 1 | Localizar todos os confirm() no Admin Panel | 15min |
| 2 | Criar componente ArchiveAppButton com AlertDialog | 1h |
| 3 | Substituir no ApplicationsTable (ou similar) | 30min |
| 4 | Verificar e corrigir deletar categoria se necessário | 30min |
| 5 | Testar em browser com extensões ativas | 15min |
| **Total** | | **~2.5h** |

## Artefatos de saída

- Componente com AlertDialog substituindo confirm()
- Teste B5 aprovado no relatório de verificação
