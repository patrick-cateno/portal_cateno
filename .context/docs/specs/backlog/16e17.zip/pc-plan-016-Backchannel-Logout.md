# PC-PLAN-016 — Back-channel Logout

**Status:** Backlog
**Agente:** security-auditor
**Prioridade:** Alta — segurança crítica fintech
**Depende de:** PC-SPEC-009, PC-SPEC-002

## Critérios de aceite

- [ ] keycloakSub preenchido na tabela User após login
- [ ] Endpoint retorna 200 com logout_token válido
- [ ] prisma.session.deleteMany remove sessões corretamente
- [ ] AuditLog registra backchannel_logout com sessionsDeleted
- [ ] Keycloak configurado com Backchannel Logout URL
- [ ] realm-cateno.json atualizado e commitado
- [ ] Teste A4 aprovado: Sign Out Keycloak → /login imediato

## Tarefas

| # | Tarefa | Estimativa |
|---|--------|-----------|
| 1 | Verificar se keycloakSub está sendo populado no callback jwt | 30min |
| 2 | Corrigir callback jwt para garantir persistência do keycloakSub | 1h |
| 3 | Corrigir endpoint backchannel-logout com busca por keycloakSub | 2h |
| 4 | Configurar Backchannel Logout URL no Keycloak Admin Console | 30min |
| 5 | Exportar realm-cateno.json atualizado | 30min |
| 6 | Teste A4 ponta a ponta | 1h |
| 7 | Commitar correções + realm atualizado | 15min |
| **Total** | | **~5.75h** |

## Artefatos de saída

- `src/lib/auth.ts` — callback jwt corrigido
- `src/app/api/auth/backchannel-logout/route.ts` — invalidação corrigida
- `keycloak/realm-cateno.json` — com Backchannel Logout URL configurado
