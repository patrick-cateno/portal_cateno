# Kickoff — PC-SPEC-016: Back-channel Logout (Implementação Completa)

**Agente:** security-auditor
**Prioridade:** Alta — segurança crítica fintech
**Estimativa:** ~5.75h

## Antes de começar

Leia a spec completa:
```
.context/docs/specs/backlog/pc-016-Backchannel-Logout/pc-spec-016-Backchannel-Logout.md
```

## Contexto do problema

O teste A4 falhou: após Sign Out no Keycloak Admin Console, o portal continuou
funcionando. A causa provável é que `keycloakSub` não está sendo populado
corretamente no callback jwt, fazendo o `prisma.session.deleteMany` não encontrar
a sessão certa.

## Passo 1 — Diagnóstico antes de qualquer código

```bash
# Verificar se keycloakSub está preenchido após login
docker compose exec postgres psql -U cateno -d portal_cateno \
  -c "SELECT id, email, \"keycloakSub\" FROM \"User\" LIMIT 5;"
```

**Se keycloakSub for NULL:** o callback jwt não está salvando o campo.
**Se keycloakSub estiver preenchido:** o problema está na busca do endpoint.

```bash
# Verificar sessões no banco
docker compose exec postgres psql -U cateno -d portal_cateno \
  -c "SELECT s.id, s.\"userId\", s.expires FROM \"Session\" s LIMIT 5;"
```

```bash
# Verificar se o Keycloak está chamando o endpoint (ver logs do portal)
# Fazer Sign Out no Keycloak Admin Console e imediatamente:
docker compose logs portal --tail=30 | grep -i "backchannel\|logout"
```

## Passo 2 — Corrigir com base no diagnóstico

### Se keycloakSub está NULL — corrigir `src/lib/auth.ts`

Leia o arquivo e localize o callback `jwt`. Garantir que `keycloakSub`
é salvo no banco a cada login:

```typescript
async jwt({ token, account, profile }) {
  if (account && profile) {
    token.keycloakSub = profile.sub;
    await prisma.user.update({
      where: { id: token.id as string },
      data: { keycloakSub: profile.sub },
    });
  }
  return token;
},
```

### Corrigir `src/app/api/auth/backchannel-logout/route.ts`

Leia o arquivo atual e aplique a correção conforme spec seção 4.2.
O ponto crítico é a busca por `keycloakSub` e o `deleteMany` correto:

```typescript
const user = await prisma.user.findFirst({
  where: { keycloakSub },
});

if (user) {
  const deleted = await prisma.session.deleteMany({
    where: { userId: user.id },
  });
  // ... AuditLog
}
```

## Passo 3 — Configurar Keycloak

No Keycloak Admin Console (`http://localhost:8080` → admin/admin):
1. Selecionar realm `cateno`
2. Clients → `portal-cateno` → Settings → Logout Settings
3. Configurar:
   - **Backchannel Logout URL:** `http://host.docker.internal:3000/api/auth/backchannel-logout`
   - **Backchannel Logout Session Required:** ON
   - **Backchannel Logout Revoke Offline Sessions:** ON
4. Save

## Passo 4 — Exportar realm atualizado

```bash
docker exec portal-cateno-keycloak \
  /opt/keycloak/bin/kc.sh export \
  --dir /tmp/export --realm cateno --users realm_file

docker cp portal-cateno-keycloak:/tmp/export/cateno-realm.json \
  ./keycloak/realm-cateno.json
```

## Passo 5 — Teste A4 ponta a ponta

1. Reinicie o dev server: `Ctrl+C` → `npm run dev`
2. Faça login no portal com qualquer usuário
3. Acesse `http://localhost:8080/admin` → Users → [usuário] → Sessions → Sign Out
4. Verifique os logs:
```bash
docker compose logs portal --tail=20 | grep -i "backchannel"
# Esperado: sessionsDeleted: 1
```
5. Tente fazer qualquer ação no portal com a aba aberta
6. ✅ Esperado: redirecionado para /login imediatamente

## Critérios de aceite

- [ ] keycloakSub preenchido na tabela User após login
- [ ] Endpoint retorna 200 com logout_token válido do Keycloak
- [ ] prisma.session.deleteMany remove a sessão corretamente
- [ ] AuditLog registra backchannel_logout com sessionsDeleted
- [ ] Keycloak configurado com Backchannel Logout URL
- [ ] realm-cateno.json atualizado e commitado
- [ ] Teste A4 aprovado: Sign Out Keycloak → /login imediato

## Validação final e commit

```bash
npx tsc --noEmit
npm run lint
npx vitest run
```

```bash
git add src/lib/auth.ts \
        src/app/api/auth/backchannel-logout/route.ts \
        keycloak/realm-cateno.json
git commit -m "fix: back-channel logout — invalidacao de sessao via keycloakSub"
git push
```

## Ao finalizar

```
workflow-manage({ action: "handoff", from: "security-auditor", to: "frontend-specialist", artifacts: ["src/lib/auth.ts", "src/app/api/auth/backchannel-logout/route.ts", "keycloak/realm-cateno.json"] })
```
