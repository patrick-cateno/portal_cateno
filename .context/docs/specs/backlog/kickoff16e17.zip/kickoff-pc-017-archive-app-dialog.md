# Kickoff — PC-SPEC-017: Archive App Dialog (shadcn/ui AlertDialog)

**Agente:** frontend-specialist
**Prioridade:** Baixa — UX, não bloqueante
**Estimativa:** ~2.5h

## Antes de começar

Leia a spec completa:
```
.context/docs/specs/backlog/pc-017-Archive-App-Dialog/pc-spec-017-Archive-App-Dialog.md
```

## Contexto do problema

O teste B5 falhou: ao clicar no ícone de arquivamento de um app no Admin Panel,
o dialog de confirmação não aparecia. O `confirm()` nativo do browser é bloqueado
por extensões de browser e configurações corporativas.

## Passo 1 — Localizar todos os confirm() no Admin Panel

```bash
# Encontrar onde confirm() é usado
grep -rn "confirm(" src/app/\(app\)/admin/ --include="*.tsx"
grep -rn "confirm(" src/components/features/admin/ --include="*.tsx" 2>/dev/null || true
```

Listar todos os arquivos encontrados antes de começar a editar.

## Passo 2 — Criar componente reutilizável ArchiveConfirmDialog

Criar ou adaptar um componente que usa `AlertDialog` do shadcn/ui.
O AlertDialog já está disponível no projeto — verificar:

```bash
ls src/components/ui/alert-dialog.tsx
```

Se não existir, instalar via shadcn:
```bash
npx shadcn@latest add alert-dialog
```

## Passo 3 — Substituir confirm() para arquivar app

Padrão a seguir (adaptar ao código existente encontrado no Passo 1):

```tsx
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

// Substituir o botão com confirm() por:
<AlertDialog>
  <AlertDialogTrigger asChild>
    <button
      className="text-neutral-400 hover:text-warning transition-colors"
      title="Arquivar aplicação"
    >
      <Archive size={16} />
    </button>
  </AlertDialogTrigger>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Arquivar aplicação</AlertDialogTitle>
      <AlertDialogDescription>
        Tem certeza que deseja arquivar <strong>{appName}</strong>?
        A aplicação não aparecerá mais no catálogo.
      </AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel>Cancelar</AlertDialogCancel>
      <AlertDialogAction
        onClick={() => archiveApplication(appId)}
        className="bg-destructive hover:bg-destructive/90 text-white"
      >
        Arquivar
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

## Passo 4 — Verificar e corrigir deletar categoria

```bash
grep -rn "confirm(" src/app/\(app\)/admin/categorias/ --include="*.tsx"
```

Se encontrar `confirm()`, aplicar o mesmo padrão de AlertDialog para consistência.

## Passo 5 — Verificar design

- Botão "Arquivar" deve ter cor de warning/destructive (não teal)
- Texto da descrição deve mencionar o nome do app
- Botão "Cancelar" fecha sem executar ação
- Ação deve acionar a Server Action corretamente

## Critérios de aceite

- [ ] Botão de arquivar app abre AlertDialog (não confirm() nativo)
- [ ] Dialog mostra nome da aplicação na mensagem
- [ ] Botão "Arquivar" aciona a Server Action corretamente
- [ ] Botão "Cancelar" fecha sem executar ação
- [ ] Deletar categoria também usa AlertDialog (se usava confirm())
- [ ] Teste B5 aprovado em browser com extensões ativas

## Validação final e commit

```bash
npx tsc --noEmit
npm run lint
npx vitest run
```

```bash
git add src/
git commit -m "fix: substituir confirm() por AlertDialog shadcn em arquivar app e deletar categoria"
git push
```

## Ao finalizar

```
workflow-manage({ action: "handoff", from: "frontend-specialist", to: "devops-specialist", artifacts: ["src/app/(app)/admin/"] })
```
