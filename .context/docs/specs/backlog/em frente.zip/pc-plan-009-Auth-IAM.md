# PC-PLAN-009 — Auth / IAM

**Status:** Backlog
**Agente:** security-auditor
**Prioridade:** Alta
**Depende de:** PC-SPEC-002 (NextAuth já feito)

## Critérios de aceitação

- [ ] realm-cateno.json versionado no repositório
- [ ] Client portal-cateno com redirect URIs dev e prod
- [ ] Roles admin, user, viewer no realm
- [ ] Back-channel logout configurado
- [ ] Import automático via docker compose
- [ ] Login funcional local com Keycloak Docker

## Tarefas

| # | Tarefa | Estimativa |
|---|--------|-----------|
| 1 | Configurar realm cateno no Keycloak local | 1h |
| 2 | Criar client portal-cateno com roles e redirect URIs | 1h |
| 3 | Configurar back-channel logout | 30min |
| 4 | Exportar realm para keycloak/realm-cateno.json | 30min |
| 5 | Adicionar volume no docker-compose.yml para import automático | 30min |
| 6 | Documentar variáveis em .env.example | 30min |
| 7 | Testar login ponta a ponta local | 1h |
| **Total** | | **~5h** |

## Artefatos de saída

- `keycloak/realm-cateno.json`
- `.env.example` atualizado
- `docker-compose.yml` com volume de import
