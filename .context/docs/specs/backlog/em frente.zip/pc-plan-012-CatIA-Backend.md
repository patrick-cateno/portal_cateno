# PC-PLAN-012 — CatIA Backend

**Status:** Backlog
**Agente:** feature-developer
**Prioridade:** Média
**Depende de:** PC-SPEC-005, PC-SPEC-007

## Critérios de aceitação

- [ ] POST /api/catia/chat com streaming SSE
- [ ] LangGraph com 4 nós funcionando
- [ ] RBAC: CatIA vê apenas apps do usuário
- [ ] Provider configurável via .env
- [ ] Timeout 60s na API Route

## Tarefas

| # | Tarefa | Estimativa |
|---|--------|-----------|
| 1 | Instalar LangGraph, LangChain, Google GenAI | 30min |
| 2 | Implementar StateGraph com 4 nós | 4h |
| 3 | Nó de busca com Prisma + RBAC | 2h |
| 4 | API Route com streaming SSE | 2h |
| 5 | Integrar com interface PC-SPEC-005 | 2h |
| 6 | Testes de comportamento | 3h |
| **Total** | | **~13.5h** |
