# PC-SPEC-009 — Auth / IAM: Configuração Keycloak

| Campo            | Valor                  |
| ---------------- | ---------------------- |
| **ID**           | PC-SPEC-009            |
| **Status**       | Backlog                |
| **Prioridade**   | Alta                   |
| **Complexidade** | Baixa                  |
| **Autor**        | Patrick Iarrocheski    |
| **Branch**       | feat/PC-009-auth-iam   |

## 1. Objetivo

Configurar o realm Keycloak `cateno` com as roles, clients e service accounts necessários para o portal. A integração NextAuth.js já foi implementada em PC-SPEC-002 — esta spec foca exclusivamente na configuração do lado do Keycloak e nas variáveis de ambiente necessárias.

## 2. O que já existe (PC-SPEC-002)

- NextAuth.js 5 integrado com Keycloak via `KeycloakProvider`
- Sincronização de roles do Keycloak para Prisma após login
- Refresh token automático
- Back-channel logout endpoint
- RBAC híbrido (roles Keycloak + Permission local)

## 3. O que esta spec cobre

### 3.1 Realm `cateno` — configuração

```json
{
  "realm": "cateno",
  "enabled": true,
  "accessTokenLifespan": 300,
  "refreshTokenMaxReuse": 0,
  "refreshTokenLifespan": 1800,
  "ssoSessionMaxLifespan": 36000,
  "bruteForceProtected": true
}
```

### 3.2 Client `portal-cateno` — configuração

```json
{
  "clientId": "portal-cateno",
  "enabled": true,
  "publicClient": false,
  "secret": "<KEYCLOAK_SECRET>",
  "standardFlowEnabled": true,
  "implicitFlowEnabled": false,
  "directAccessGrantsEnabled": false,
  "serviceAccountsEnabled": false,
  "redirectUris": [
    "https://portal.cateno.com.br/api/auth/callback/keycloak",
    "http://localhost:3000/api/auth/callback/keycloak"
  ],
  "webOrigins": [
    "https://portal.cateno.com.br",
    "http://localhost:3000"
  ]
}
```

### 3.3 Roles do realm

| Role | Descrição |
|------|-----------|
| `admin` | Acesso total — registra apps, gerencia usuários |
| `user` | Acesso padrão — vê todas as aplicações |
| `viewer` | Acesso restrito — vê apenas apps com Permission explícita |

### 3.4 Service account `health-checker`

```json
{
  "clientId": "health-checker",
  "enabled": true,
  "publicClient": false,
  "serviceAccountsEnabled": true,
  "standardFlowEnabled": false,
  "directAccessGrantsEnabled": false
}
```

> O Health Checker usa `client_credentials` para obter um token simples. Na prática, como o PATCH /health usa um `HEALTH_CHECKER_SECRET` estático (ver PC-SPEC-007), este client pode ser simplificado para apenas um secret compartilhado em `.env.local`.

### 3.5 Back-channel logout

No Keycloak, configurar no client `portal-cateno`:
- **Backchannel Logout URL:** `https://portal.cateno.com.br/api/auth/backchannel-logout`
- **Backchannel Logout Session Required:** `true`

### 3.6 Variáveis de ambiente

```env
# .env.local
KEYCLOAK_ID=portal-cateno
KEYCLOAK_SECRET=<secret-do-client-no-keycloak>
KEYCLOAK_ISSUER=https://auth.cateno.com.br/realms/cateno
NEXTAUTH_URL=https://portal.cateno.com.br
NEXTAUTH_SECRET=<secret-aleatorio-32-chars>
HEALTH_CHECKER_SECRET=<secret-para-o-health-checker>
```

### 3.7 Export do realm para versionamento

```bash
# Exportar configuração do realm para o repositório
docker exec keycloak /opt/keycloak/bin/kc.sh export \
  --dir /tmp/export --realm cateno --users realm_file

# Salvar em:
keycloak/realm-cateno.json
```

## 4. Critérios de Aceite

- [ ] Realm `cateno` criado e exportado como `keycloak/realm-cateno.json`
- [ ] Client `portal-cateno` com redirect URIs corretos (dev e prod)
- [ ] Roles `admin`, `user`, `viewer` criadas no realm
- [ ] Back-channel logout configurado apontando para `/api/auth/backchannel-logout`
- [ ] `HEALTH_CHECKER_SECRET` definido em `.env.local` e `.env.example`
- [ ] Import automático via `docker compose up` (volume com realm-cateno.json)
- [ ] Login funcionando em ambiente local com Keycloak via Docker

## 5. Dependências

- **Depende de:** PC-SPEC-002 (NextAuth já implementado)
- **Bloqueante para:** PC-SPEC-011 (Health Checker precisa do secret)
