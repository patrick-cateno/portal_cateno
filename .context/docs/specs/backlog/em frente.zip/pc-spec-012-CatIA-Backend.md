# PC-SPEC-012 — CatIA Backend (LangGraph + Gemini)

| Campo            | Valor                      |
| ---------------- | -------------------------- |
| **ID**           | PC-SPEC-012                |
| **Status**       | Backlog                    |
| **Prioridade**   | Média                      |
| **Complexidade** | Alta                       |
| **Autor**        | Patrick Iarrocheski        |
| **Branch**       | feat/PC-012-catia-backend  |

## 1. Objetivo

Implementar o backend do CatIA como uma API Route do Next.js (`/api/catia/chat`), conectando a interface conversacional (PC-SPEC-005) com dados reais do catálogo via LangGraph + LangChain.js + Google Gemini. A interface já existe — esta spec implementa a lógica de orquestração real.

## 2. Decisão de Arquitetura

**Por que dentro do Next.js e não separado?**
- O Langflow (já no docker-compose) é usado para **design e experimentação** dos fluxos
- A execução em produção usa LangGraph diretamente no Next.js via API Route
- Sem latência de rede adicional — mesma instância acessa o Prisma e o LLM
- Se o CatIA ficar lento, o timeout isolado da API Route protege o resto do portal

**Alinhamento com PC-SPEC-005:**
A spec 005 já definiu: LangGraph (StateGraph), LangChain.js, Google Gemini como provider padrão, configurável via `.env`.

## 3. Estrutura

```
src/
├── app/
│   └── api/
│       └── catia/
│           └── chat/
│               └── route.ts      # POST /api/catia/chat (streaming SSE)
└── lib/
    └── catia/
        ├── graph.ts              # StateGraph LangGraph
        ├── nodes/
        │   ├── intent.ts         # Nó: reconhecimento de intenção
        │   ├── search.ts         # Nó: busca de apps no Prisma
        │   ├── status.ts         # Nó: status do portal
        │   └── response.ts       # Nó: geração de resposta final
        ├── tools.ts              # Ferramentas disponíveis ao LLM
        └── prompts.ts            # System prompts e templates
```

## 4. LangGraph StateGraph

```typescript
// src/lib/catia/graph.ts
import { StateGraph, Annotation } from '@langchain/langgraph';
import { ChatGoogleGenerativeAI } from '@langchain/google-genai';

const GraphState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({ reducer: (x, y) => x.concat(y) }),
  intent: Annotation<string>(),
  apps: Annotation<any[]>(),
});

const model = new ChatGoogleGenerativeAI({
  model: process.env.AI_MODEL ?? 'gemini-1.5-flash',
  streaming: true,
});

const graph = new StateGraph(GraphState)
  .addNode('recognizeIntent', recognizeIntentNode)
  .addNode('searchApps', searchAppsNode)
  .addNode('getStatus', getStatusNode)
  .addNode('generateResponse', generateResponseNode)
  .addEdge('__start__', 'recognizeIntent')
  .addConditionalEdges('recognizeIntent', routeByIntent)
  .addEdge('searchApps', 'generateResponse')
  .addEdge('getStatus', 'generateResponse')
  .addEdge('generateResponse', '__end__')
  .compile();
```

## 5. API Route com streaming SSE

```typescript
// src/app/api/catia/chat/route.ts
import { getServerSession } from 'next-auth';

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { message, history } = await request.json();

  // Streaming SSE
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      try {
        for await (const chunk of await graph.stream({
          messages: [...history, { role: 'user', content: message }],
          userId: session.user.id,
          userRoles: session.user.roles,
        })) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`));
        }
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
```

## 6. Busca de apps — via Prisma (não via HTTP)

```typescript
// src/lib/catia/nodes/search.ts
// CatIA acessa o Prisma diretamente — mesma instância Next.js
// Filtragem por roles do usuário — CatIA vê apenas o que o usuário vê

export async function searchAppsNode(state: GraphState) {
  const apps = await prisma.application.findMany({
    where: {
      ...(state.userRoles.includes('viewer') && {
        permissions: { some: { role: 'viewer', canView: true } },
      }),
      OR: [
        { name: { contains: state.searchQuery, mode: 'insensitive' } },
        { description: { contains: state.searchQuery, mode: 'insensitive' } },
      ],
    },
    include: { category: true },
    take: 5,
  });
  return { apps };
}
```

## 7. Variáveis de ambiente

```env
AI_PROVIDER=google          # google | openai | anthropic
AI_MODEL=gemini-1.5-flash   # modelo configurável
GOOGLE_API_KEY=...          # chave da Google AI
```

## 8. Critérios de Aceite

- [ ] POST /api/catia/chat com streaming SSE funcionando
- [ ] LangGraph StateGraph com 4 nós (intent, search, status, response)
- [ ] Busca de apps via Prisma com RBAC (vê apenas o que o usuário vê)
- [ ] Streaming chegando na interface do PC-SPEC-005
- [ ] Provider configurável via .env (Google Gemini por padrão)
- [ ] Timeout: API Route com máx 60s antes de encerrar

## 9. Dependências

- **Depende de:** PC-SPEC-005 (interface), PC-SPEC-007 (dados), PC-SPEC-002 (auth)
- **Não é bloqueante** para outras specs
