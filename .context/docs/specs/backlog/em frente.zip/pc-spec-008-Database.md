# PC-SPEC-008 — Database: Evolução do Schema Prisma

| Campo            | Valor                     |
| ---------------- | ------------------------- |
| **ID**           | PC-SPEC-008               |
| **Status**       | Backlog                   |
| **Prioridade**   | Alta — pré-requisito      |
| **Complexidade** | Baixa                     |
| **Autor**        | Patrick Iarrocheski       |
| **Branch**       | feat/PC-008-database      |

## 1. Objetivo

Evoluir o schema Prisma existente (criado em PC-SPEC-001) com os modelos necessários para health checking, métricas de uso e permissões granulares por aplicação. Não reescreve o schema — apenas adiciona.

## 2. O que já existe (PC-SPEC-001)

```prisma
model User          { ... }    // id, email, name, avatar, roles, favorites
model Role          { ... }    // id, name, userId
model Category      { ... }    // id, name, slug, icon, order
model Application   { ... }    // id, name, slug, description, status, url, userCount, trend
model Favorite      { ... }    // userId + applicationId
model AuditLog      { ... }    // entity, action, changes, userId, ipAddress
```

## 3. O que precisa ser adicionado

### 3.1 AppHealth — histórico de checks do Health Checker

```prisma
model AppHealth {
  id              String      @id @default(cuid())
  applicationId   String
  application     Application @relation(fields: [applicationId], references: [id], onDelete: Cascade)
  status          AppStatus   // online | maintenance | offline
  responseTimeMs  Int?
  uptimePct       Float?
  errorMessage    String?
  checkedAt       DateTime    @default(now())

  @@index([applicationId, checkedAt(sort: Desc)])
  @@map("app_health")
}
```

### 3.2 AppMetrics — métricas de uso por período

```prisma
model AppMetrics {
  id            String      @id @default(cuid())
  applicationId String
  application   Application @relation(fields: [applicationId], references: [id], onDelete: Cascade)
  activeUsers   Int
  trendPct      Float
  period        MetricsPeriod
  recordedAt    DateTime    @default(now())

  @@index([applicationId, recordedAt(sort: Desc)])
  @@map("app_metrics")
}

enum MetricsPeriod {
  last_7_days
  last_30_days
  last_90_days
}
```

### 3.3 Permission — controle granular por app (já referenciado em PC-SPEC-002)

```prisma
model Permission {
  id            String      @id @default(cuid())
  userId        String
  applicationId String
  canView       Boolean     @default(true)
  canExecute    Boolean     @default(false)
  createdAt     DateTime    @default(now())

  user          User        @relation(fields: [userId], references: [id], onDelete: Cascade)
  application   Application @relation(fields: [applicationId], references: [id], onDelete: Cascade)

  @@unique([userId, applicationId])
  @@index([userId])
  @@index([applicationId])
  @@map("permission")
}
```

### 3.4 Campos adicionais em Application

```prisma
// Adicionar ao model Application existente:
healthCheckUrl  String?            // URL para o Health Checker verificar
integrationType String  @default("redirect")  // redirect | embed | modal
health          AppHealth[]
metrics         AppMetrics[]
permissions     Permission[]
```

### 3.5 Enum AppStatus

```prisma
enum AppStatus {
  online
  maintenance
  offline
  archived
}
// Migrar campo status de String para AppStatus
```

## 4. Índices de performance

```sql
-- Para o endpoint GET /api/applications/status (LATERAL JOIN)
CREATE INDEX CONCURRENTLY idx_app_health_latest
ON app_health (application_id, checked_at DESC);

-- Para filtragem RBAC por permissão
CREATE INDEX CONCURRENTLY idx_permission_app_view
ON permission (application_id, can_view)
WHERE can_view = true;
```

## 5. Seed — atualizar dados iniciais

```typescript
// prisma/seed.ts — adicionar healthCheckUrl e integrationType nas apps seed
const apps = [
  {
    name: 'Gestão de Cartões',
    slug: 'gestao-de-cartoes',
    healthCheckUrl: 'https://cartoes.cateno.com.br/health',
    integrationType: 'redirect',
    // ...
  },
  // ...
];
```

## 6. Política de retenção

| Tabela | Retenção | Job |
|--------|----------|-----|
| `app_health` | 7 dias | pg_cron diário às 02h |
| `app_metrics` | 90 dias | pg_cron semanal |

## 7. Critérios de Aceite

- [ ] `npx prisma migrate dev` roda sem erros
- [ ] Models AppHealth e AppMetrics criados com índices
- [ ] Permission model com unique constraint userId+applicationId
- [ ] Application com campos healthCheckUrl e integrationType
- [ ] Seed atualizado com healthCheckUrl para todos os apps
- [ ] pg_cron configurado para retenção

## 8. Dependências

- **Depende de:** PC-SPEC-001 (schema base)
- **Bloqueante para:** PC-SPEC-007, PC-SPEC-011
